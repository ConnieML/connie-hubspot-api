import * as FlexPlugin from '@twilio/flex-plugin';

import HubspotFlex1Plugin from './HubspotFlex1Plugin';

FlexPlugin.loadPlugin(HubspotFlex1Plugin);
