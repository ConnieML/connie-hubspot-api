# Hubspot Twilio Flex Plugin

To run this plugin locally, open a terminal window, navigate to the "plugin-hubspot" folder and type "twilio flex:plugins:start"


NOTE: If this is the first time you're implementing a Flex plugin, please make sure you go through the Quickstart to familiarise yourself with Flex plugins:https://www.twilio.com/docs/flex/quickstart/getting-started-plugin
