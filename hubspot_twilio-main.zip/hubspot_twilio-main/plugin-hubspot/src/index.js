import * as FlexPlugin from '@twilio/flex-plugin';

import HubspotPlugin from './HubspotPlugin';

FlexPlugin.loadPlugin(HubspotPlugin);
